import os
import shutil
from pathlib import Path

#----------------
#FUNCTIONS
#----------------

def true_reset():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
        os.makedirs(r"..\UNDERTALE_linux_practice_mod")

    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
        os.makedirs(r"..\UNDERTALE")

    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
        os.makedirs(r"..\UNDERTALE_linux_steamver")
    
def asgore():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\asgore", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\asgore", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\asgore", r"..\UNDERTALE_linux_steamver")
    
def asriel():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\asriel", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\asriel", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\asriel", r"..\UNDERTALE_linux_steamver")
    
def flowey():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\flowey", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\flowey", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\flowey", r"..\UNDERTALE_linux_steamver")
    
def mad_dummy():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\mad_dummy", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\mad_dummy", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\mad_dummy", r"..\UNDERTALE_linux_steamver")
    
def mettaton_ex():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\mettaton_ex", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\mettaton_ex", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\mettaton_ex", r"..\UNDERTALE_linux_steamver")
    
def muffet():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\muffet", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\muffet", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\muffet", r"..\UNDERTALE_linux_steamver")
    
def papyrus():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\papyrus", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\papyrus", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\papyrus", r"..\UNDERTALE_linux_steamver")
    
def sans():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\sans", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\sans", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\sans", r"..\UNDERTALE_linux_steamver")
    
def so_sorry():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\so_sorry", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\so_sorry", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\so_sorry", r"..\UNDERTALE_linux_steamver")
    
def toriel():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\toriel", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\toriel", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\toriel", r"..\UNDERTALE_linux_steamver")
    
def undyne():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\undyne", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\undyne", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\undyne", r"..\UNDERTALE_linux_steamver")
    
def undyne_the_undying():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\fights\undyne_the_undying", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\fights\undyne_the_undying", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\fights\undyne_the_undying", r"..\UNDERTALE_linux_steamver")
    
def geno_hotlands():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\geno_hotlands", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\geno_hotlands", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\geno_hotlands", r"..\UNDERTALE_linux_steamver")
    
def geno_snowdin():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\geno_snowdin", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\geno_snowdin", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\geno_snowdin", r"..\UNDERTALE_linux_steamver")
    
def geno_waterfall():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\geno_waterfall", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\geno_waterfall", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\geno_waterfall", r"..\UNDERTALE_linux_steamver")
    
def neutral_hotlands():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\neutral_hotlands", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\neutral_hotlands", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\neutral_hotlands", r"..\UNDERTALE_linux_steamver")
    
def neutral_new_home():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\neutral_new_home", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\neutral_new_home", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\neutral_new_home", r"..\UNDERTALE_linux_steamver")
    
def neutral_snowdin():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\neutral_snowdin", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\neutral_snowdin", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\neutral_snowdin", r"..\UNDERTALE_linux_steamver")
    
def neutral_waterfall():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\neutral_waterfall", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\neutral_waterfall", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\neutral_waterfall", r"..\UNDERTALE_linux_steamver")
    
def true_lab():
    if linux_practice_mod.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_practice_mod")
    if undertale.exists():
        shutil.rmtree(r"..\UNDERTALE")
    if linux_steamver.exists():
        shutil.rmtree(r"..\UNDERTALE_linux_steamver")
    
    shutil.copytree(r".\files\Undertale\areas\true_lab", r"..\UNDERTALE")
    shutil.copytree(r".\files\Undertale\areas\true_lab", r"..\UNDERTALE_linux_practice_mod")
    shutil.copytree(r".\files\Undertale\areas\true_lab", r"..\UNDERTALE_linux_steamver")
    
def change_area():
    area = input("What area would you like? \n(Ruins, Snowdin, Waterfall, Hotlands, New Home, True Lab) ")
    
    if area.upper() == "SNOWDIN" or area.upper() == "WATERFALL" or area.upper() == "HOTLANDS":
        route = input("What route would you like \n(Neutral, Pacifist, Genocide) ")
        if route.upper() == "PACIFIST" or route.upper() == "P" or route.upper() == "N":
            route = "NEUTRAL"
        elif route.upper() == "GENO" or route.upper() == "G":
            route = "GENOCIDE"
        
    if area.upper() == "RUINS":
        true_reset()
    elif area.upper() == "NEW HOME":
        neutral_new_home()
    elif area.upper() == "TRUE LAB":
        true_lab()
    elif area.upper() == "SNOWDIN" and route.upper() == "GENOCIDE":
        geno_snowdin()
    elif area.upper() == "WATERFALL" and route.upper() == "GENOCIDE":
        geno_waterfall()
    elif area.upper() == "HOTLANDS" and route.upper() == "GENOCIDE":
        geno_hotlands()
    elif area.upper() == "SNOWDIN" and route.upper() == "NEUTRAL":
        neutral_snowdin()
    elif area.upper() == "WATERFALL" and route.upper() == "NEUTRAL":
        neutral_waterfall()
    elif area.upper() == "HOTLANDS" and route.upper() == "NEUTRAL":
        neutral_hotlands()
    else:
        print("invalid input")
        
def change_save():
    
    fight = input("What fight would you like? \n(Agore, Asriel, Flowey, Mad Dummy, Mettaton EX, Muffet, Papyrus, Sans, So Sorry, Toriel, Undyne, Undyne the Undying) ")
    
    if fight.upper() == "ASGORE":
        asgore()
    elif fight.upper() == "ASRIEL":
        asriel()
    elif fight.upper() == "FLOWEY" or fight.upper() == "PHOTOSHOP FLOWEY" or fight.upper() == "OMEGA FLOWEY":
        flowey()
    elif fight.upper() == "MAD DUMMY":
        mad_dummy()
    elif fight.upper() == "METTATON EX" or fight.upper() == "METTATON":
        mettaton_ex()
    elif fight.upper() == "MUFFET":
        muffet()
    elif fight.upper() == "PAPYRUS":
        papyrus()
    elif fight.upper() == "SANS":
        sans()
    elif fight.upper() == "SO SORRY":
        so_sorry()
    elif fight.upper() == "TORIEL":
        toriel()
    elif fight.upper() == "UNDYNE":
        undyne()
    elif fight.upper() == "UNDYNE THE UNDYING":
        undyne_the_undying()
    
#----------------
#MAIN PROGRAM
#----------------
    
linux_practice_mod = Path(r"..\UNDERTALE_linux_practice_mod")
undertale = Path(r"..\UNDERTALE")
linux_steamver = Path(r"..\UNDERTALE_linux_steamver")

action = input("What would you like to do? \n(Reset / Change Save) ")

if action.upper() == "TRUE RESET" or action.upper() == "RESET":
    true_reset()
elif action.upper() == "CHANGE SAVE":
    file_type = input("What type of save would you like? \n(Area / Battle) ")
    if file_type.upper() == "AREA":
        change_area()
    elif file_type.upper() == "BATTLE":
        change_save()
    else:
        print("invalid input")
else:
    print("invalid input")